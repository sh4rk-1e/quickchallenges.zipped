// Asked AI how to do grayscale; rabbitholed until it told me there was an opacity modifier, then used that.
import SwiftUI

    struct ContentView: View {
        @State var varby = true
        var body: some View {
            VStack {
                Spacer()
                HStack{
                    Spacer()
                    Button("0") {varby.toggle()}
                        .font(.system(size: 100))
                        .foregroundStyle(varby ? .white : .black)
                        .padding(.all)
                }
                HStack{
                    Spacer()
                    ZStack{
                        Circle()
                            .fill(varby ? .gray : .black.opacity(0.7))
                        Text("AC")
                            .font(.system(size: 35))
                            .foregroundStyle(varby ? .black : .white)
                        
                    }
                    ZStack{
                        Circle()
                            .fill(varby ? .gray : .black.opacity(0.7))
                        Text("+/-")
                            .font(.system(size: 35))
                            .foregroundStyle(varby ? .black : .white)
                    }
                    ZStack{
                        Circle()
                            .fill(varby ? .gray : .black.opacity(0.7))
                        Text("%")
                            .font(.system(size: 40))
                            .foregroundStyle(varby ? .black : .white)
                    }
                    ZStack{
                        Circle()
                            .fill(.orange)
                        Text("÷")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    Spacer()
                }
                HStack{
                    Spacer()
                    ZStack{
                        Circle()
                            .fill(.secondary)
                        Text("7")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    ZStack{
                        Circle()
                            .fill(.secondary)
                        Text("8")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    ZStack{
                        Circle()
                            .fill(.secondary)
                        Text("9")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    ZStack{
                        Circle()
                            .fill(.orange)
                        Text("x")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    Spacer()
                }
                HStack{
                    Spacer()
                    ZStack{
                        Circle()
                            .fill(.secondary)
                        Text("4")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    ZStack{
                        Circle()
                            .fill(.secondary)
                        Text("5")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    ZStack{
                        Circle()
                            .fill(.secondary)
                        Text("6")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    ZStack{
                        Circle()
                            .fill(.orange)
                        Text("-")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    Spacer()
                }
                HStack{
                    Spacer()
                    ZStack{
                        Circle()
                            .fill(.secondary)
                        Text("1")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    ZStack{
                        Circle()
                            .fill(.secondary)
                        Text("2")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    ZStack{
                        Circle()
                            .fill(.secondary)
                        Text("3")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    ZStack{
                        Circle()
                            .fill(.orange)
                        Text("+")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    Spacer()
                }
                HStack{
                    Spacer()
                    ZStack{
                        Capsule(style: .circular)
                            .fill(.secondary)
                            .frame(width: 190, height: 105)
                        Text("0")
                            .frame(maxWidth: 140, alignment: .leading)
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    ZStack{
                        Circle()
                            .fill(.secondary)
                        Text(".")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                    ZStack{
                        Circle()
                            .fill(.orange)
                        Text("=")
                            .foregroundStyle(varby ? .white : .black)
                            .font(.system(size: 40))
                    }
                Spacer()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(varby ? .black : .white)
        }
        
    }

